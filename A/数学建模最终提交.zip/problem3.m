clc; close all; clear;
warning off

% 参数设置
luoju_values = linspace(50e-2, 20e-2, 1000); % 螺距从大到小，单位为米
L1 = 341e-2; 
D1 = L1 - 27.5e-2 * 2; 
L2 = 220e-2; 
D2 = L2 - 27.5e-2 * 2; 

% 初始条件
theta0 = 32*pi; 
dt = 0.1; % 时间步长
N = 223; % 龙头+龙身+龙尾的总个数

% 循环遍历不同的螺距值
luoju_at_contact = 0; % 记录接触时的螺距值
flag_contact = false; % 标志位，标记是否发生接触

for luoju_idx = 1:length(luoju_values)
    luoju = luoju_values(luoju_idx); % 当前螺距值
    k = luoju / (2 * pi); % 螺线方程的系数 k
    
    % 生成螺线图
    theta = 16*2*pi:-0.01:0*pi; % 从16圈减到0圈的角度
    r = k * theta; % 螺线半径
    x = r .* cos(theta); % x 坐标
    y = r .* sin(theta); % y 坐标
    figure(1)
    set(gcf, 'Position', [200 200 600 600]); % 图形窗口大小和位置
    plot(x, y, '--') % 绘制螺线
    axis equal
    grid on
    xlabel('x')
    ylabel('y')
    hold on
    
    % 初始条件
    mydtheta = @(t, theta) -1 / (k * sqrt(1 + theta.^2)); % ODE 方程
    flag = 0;
    step = 0;
    
    % 记录每个孔在时间区间内的位置
    X = nan * zeros(N + 1, 3); % X 坐标矩阵
    Y = nan * zeros(N + 1, 3); % Y 坐标矩阵
    Theta = nan * zeros(N + 1, 3); % 角度矩阵
    Theta(1, 3) = theta0; % 初始角度
    
    % 设置板的离散点数量
    n = 20; m = 40;
    
    % 开始时间步长循环
    while flag == 0
        step = step + 1; % 记录步数
        X(:, 1) = X(:, 3);
        Y(:, 1) = Y(:, 3);
        Theta(:, 1) = Theta(:, 3);
        
        % 使用 ode45 求解 ODE
        tspan = [0, dt / 2, dt];
        [tt, theta] = ode45(mydtheta, tspan, Theta(1, 1)); % 数值积分计算角度
        X1 = k * theta .* cos(theta); % 计算 X 坐标
        Y1 = k * theta .* sin(theta); % 计算 Y 坐标
        
        X(1, :) = X1;
        Y(1, :) = Y1;
        Theta(1, :) = theta;
        
        % 更新每个孔的坐标
        for j = 2:length(tt)
            for i = 2:N + 1
                d = D1 * (i <= 2) + D2 * (i > 2); % 选择距离 D1 或 D2
                thetaij = solve_theta(luoju, X(i - 1, j), Y(i - 1, j), Theta(i - 1, j), d); % 计算新的角度
                Theta(i, j) = thetaij;
                X(i, j) = k * thetaij * cos(thetaij);
                Y(i, j) = k * thetaij * sin(thetaij);
            end
        end

        % 检查是否达到一定螺距位置
        if k * Theta(1, end) >= 4.5
            break; % 达到限制值，退出循环
        end

        % 检查是否发生接触
        for i = 1:N
            x_1 = X(i, end); x_2 = X(i + 1, end);
            y_1 = Y(i, end); y_2 = Y(i + 1, end);
            if check_contact(x_1, y_1, x_2, y_2, X, Y, Theta, i, L1, L2, n, m)
                flag = 1; % 发生接触
                luoju_at_contact = luoju; % 记录螺距值
                flag_contact = true;
                break;
            end
        end
    end

    % 如果接触已发生，退出外层循环
    if flag_contact
        break;
    end
end

% 显示结果
if flag_contact
    disp(['接触时的螺距值为: ', num2str(luoju_at_contact)]);
else
    disp('在给定的螺距范围内没有检测到接触。');
end

% 计算螺旋线上的新角度 theta
function theta = solve_theta(luoju, x1, y1, theta1, d)
    k = luoju / (2 * pi);
    fun = @(theta) (k * theta * cos(theta) - x1)^2 + (k * theta * sin(theta) - y1)^2 - d^2;
    q = 0.01; % 初始搜索步长
    options = optimoptions('fsolve', 'Display', 'off');
    theta = fsolve(fun, theta1 + q, options);
    while theta <= theta1 || abs(k * theta - k * theta1) > luoju / 2
        q = q + 0.01;
        theta = fsolve(fun, theta + q, options);
    end
end

% 检查两个孔之间是否发生接触
function flag = check_contact(x_1, y_1, x_2, y_2, X, Y, Theta, i, L1, L2, n, m)
    theta_1 = Theta(i, end);
    theta_2 = Theta(i + 1, end);
    index1 = find((theta_1 + 2 * pi - Theta(:, end)) > 0);
    index1 = index1(end - 2:end);
    index2 = find(Theta(:, end) - (theta_2 + 2 * pi) > 0);
    if isempty(index2)
        flag = false;
        return;
    else
        index2 = index2(1:min(3, length(index2)));
    end
    index_i = index1(1):index2(end);
    for kk = 1:length(index_i) - 1
        X2_1 = [X(index_i(kk), end); Y(index_i(kk), end)];
        X2_2 = [X(index_i(kk + 1), end); Y(index_i(kk + 1), end)];
        panduan = find_if_intersect(L1, [x_1; y_1], [x_2; y_2], L2, X2_1, X2_2, n, m);
        if panduan
            flag = true;
            return;
        end
    end
    flag = false;
end

% 检查是否相交
function flag = find_if_intersect(L1, X1_1, X1_2, L2, X2_1, X2_2, n, m)
    k1 = (X1_1(2) - X1_2(2)) / (X1_1(1) - X1_2(1));
    k1_ = -1 / k1;
    k2 = (X2_1(2) - X2_2(2)) / (X2_1(1) - X2_2(1));
    k2_ = -1 / k2;
    X1_center = (X1_1 + X1_2) / 2;
    X2_center = (X2_1 + X2_2) / 2;
    A = [k1_ -1; k2_ -1];
    P = A \ [k1_ * X1_center(1) - X1_center(2); k2_ * X2_center(1) - X2_center(2)];
    vec1 = X1_center - P;
    vec2 = X2_center - P;
    theta1 = angle(vec1(1) + 1i * vec1(2));
    theta2 = angle(vec2(1) + 1i * vec2(2));
    if theta1 < theta2
        flag = true;
    else
        flag = false;
    end
end
