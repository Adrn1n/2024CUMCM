clc; close all; clear;
warning off

% 参数设置
luoju = 55e-2; % 螺距，单位为米
k = luoju / (2 * pi); % 螺线方程的系数 r = k * theta
L1 = 341e-2; % 长方形的长度，单位为米
D1 = L1 - 27.5e-2 * 2; % 龙头把手两个孔之间的距离，考虑了孔的直径
L2 = 220e-2; % 其他凳子的长度，单位为米
D2 = L2 - 27.5e-2 * 2; % 其他凳子把手两个孔之间的距离，考虑了孔的直径

% 画出部分螺线
theta = 32*pi:-0.01:0*pi; % 角度范围，从16圈到0圈
r = k * theta; % 螺线的半径
x = r.* cos(theta); % x坐标
y = r.* sin(theta); % y坐标
figure(1)
set(gcf, 'Position', [200 200 600 600]); % 设置图形窗口位置和大小
plot(x, y, '--') % 绘制螺线
axis equal % 坐标轴比例相等
grid on % 显示网格
xlabel('x') % x轴标签
ylabel('y') % y轴标签
hold on % 保持当前图形

% 初始条件设置
mydtheta = @(t, theta) -1 / (k * sqrt(1 + theta.^2)); % 定义螺旋线的微分方程
theta0 = 57.032076651015522; % 初始位置的角度
dt = 0.1; % 时间步长
flag = 0; % 标记是否发生接触
step = 0; % 时间步数

N = 223; % 龙头、龙身和龙尾的总个数
X = nan * zeros(N + 1, 3); % 记录每个把手点在一个时间区间内的值
Y = nan * zeros(N + 1, 3); % 每一行代表每个凳子的前把手孔的位置在各个时间点处的值
Theta = nan * zeros(N + 1, 3); % 记录每个孔在时间区间的位置对应的角度theta
Theta(1, 3) = theta0; % 头把手初始时刻(t=300)的角度值

% 创建用于存储位置和速度随时间变化的数据的数组
PositionData = nan(N + 1, 3, step + 1); % 位置数据，x, y, theta
SpeedData = nan(N + 1, step + 1); % 速度数据

while flag == 0 % 如果flag=0，说明一直没有接触，可以继续往前进
    step = step + 1;
    X(:, 1) = X(:, 3);
    Y(:, 1) = Y(:, 3);
    Theta(:, 1) = Theta(:, 3); % 开始下一时间步之前，把当前时间区间末尾处的各个把手位移值当作下一个区间开始的数据
    
    tspan = [0, dt / 2, dt]; % 求解下一个步长下的位置点
    [tt, theta] = ode45(mydtheta, tspan, Theta(1, 1)); % 龙格库塔法求解
    X1 = k * theta .* cos(theta); % 计算下一个时刻头部把手的x坐标
    Y1 = k * theta .* sin(theta); % 计算下一个时刻头部把手的y坐标
    X(1, :) = X1;
    Y(1, :) = Y1;
    Theta(1, :) = theta;
    
    for j = 2:length(tt)
        for i = 2:N + 1
            d = D1 * (i <= 2) + D2 * (i > 2); % 判断是第一个凳子还是其他凳子
            thetaij = solve_theta(luoju, X(i - 1, j), Y(i - 1, j), Theta(i - 1, j), d); % 求解下一个孔的角度值
            Theta(i, j) = thetaij;
            X(i, j) = k * thetaij * cos(thetaij);
            Y(i, j) = k * thetaij * sin(thetaij);
        end
    end
    
    hp = plot(X(:, end), Y(:, end), 'k-', 'LineWidth', 1.2, 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'r'); % 更新当前时刻的龙
    title({['t=', num2str(300 + step * dt), ' s'], '继续盘入，轨迹'})
    drawnow
    
    % 判断是否接触
    for i = 1:N
        x_1 = X(i, 2); x_2 = X(i + 1, 2); % 当前两个孔的x坐标
        y_1 = Y(i, 2); y_2 = Y(i + 1, 2); % 当前两个孔的y坐标
        theta_1 = Theta(i, 2); % 当前孔的角度
        theta_2 = Theta(i + 1, 2); % 下一个孔的角度
        
        % 寻找可能的交点
        index1 = find((theta_1 + 2 * pi - Theta(:, 2)) > 0); % 从外面一层找危险点
        index1 = index1(end - 2:end); % 最近的三个点的指标
        index2 = find(Theta(:, 2) - (theta_2 + 2 * pi) > 0); % 找到距离后把手最近的外面一层的三个点的指标
        if isempty(index2)
            break; % 如果到达了盘入口附近，直接跳出循环，开始下一个时刻位置更新
        else
            index2 = index2(1:min(3, length(index2))); % 找到最近的三个点的指标
        end
        index_i = index1(1):index2(end); % 这是当前全部要考虑的外面一层的把手点的位置指标，从小到大（逆时针排布）
        n = 20; m = 40; % 长方形的均匀离散点数量
        for kk = 1:length(index_i) - 1
            X2_1 = [X(index_i(kk), 2); Y(index_i(kk), 2)]; % 当前把手点的坐标
            X2_2 = [X(index_i(kk + 1), 2); Y(index_i(kk + 1), 2)]; % 下一个把手点的坐标
            panduan = find_if_intersect(L1 * (i <= 1) + L2 * (i > 1), [x_1; y_1], [x_2; y_2], L2, X2_1, X2_2, n, m); % 判断是否相交
            if ~isempty(panduan)
                flag = 1; % 如果有相交，设置flag为1
                break;
            end
        end
        if flag == 1
            break;
        end
    end
    
    % 存储位置和速度数据
    PositionData(:, :, step) = [X(:, end), Y(:, end), Theta(:, end)];
    v = zeros(N + 1, length(tt));
    v(1, :) = 1; % 第一个孔的速度

    for j = 2:length(tt)
        for i = 2:N + 1
            % 计算各个孔的速度
            tan_phi_i = (sin(Theta(i, j)) + Theta(i, j) * cos(Theta(i, j))) / (cos(Theta(i, j)) - Theta(i, j) * sin(Theta(i, j)));
            tan_phi_i1 = (sin(Theta(i - 1, j)) + Theta(i - 1, j) * cos(Theta(i - 1, j))) / (cos(Theta(i - 1, j)) - Theta(i - 1, j) * sin(Theta(i - 1, j)));
            tan_phi_ij = (Theta(i, j) * sin(Theta(i, j)) - Theta(i - 1, j) * sin(Theta(i - 1, j))) / (Theta(i, j) * cos(Theta(i, j)) - Theta(i - 1, j) * cos(Theta(i - 1, j)));
            
            % 更新速度
            v(i, j) = v(i - 1, j) * (cos(atan(tan_phi_i1) - atan(tan_phi_ij))) / (cos(atan(tan_phi_ij) - atan(tan_phi_i)));
        end
    end
    SpeedData(:, step) = v(:, end);
    
    delete(hp) % 删除旧的图形，准备绘制下一个时间步
end

% 最后一个时间步下的龙的位置更新
hp = plot(X(:, end), Y(:, end), 'k-', 'LineWidth', 1.2, 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
title({['t=', num2str(300 + step * dt), ' s'], '继续盘入，轨迹'})
drawnow

% 输出位置和速度数据以供进一步分析
disp('位置数据：');
disp(PositionData);
disp('速度数据：');
disp(SpeedData);

% 求解螺旋线上的点的角度
function theta = solve_theta(luoju, x1, y1, theta1, d) 
    k = luoju / 2 / pi; % 螺线方程的系数
    fun = @(theta)(k*theta.*cos(theta) - x1).^2 + (k*theta.*sin(theta) - y1).^2 - d^2; % 距离公式
    q = 0.01; % 初始猜测
    options = optimoptions('fsolve', 'Display', 'off'); % 不显示求解过程
    theta = fsolve(fun, theta1 + q, options); % 求解角度
    while theta <= theta1 || abs(k*theta - k*theta1) > luoju / 2 % 确保角度大于theta1
        q = q + 0.1;
        theta = fsolve(fun, theta + q, options); % 重新求解
    end
end

% 判断两个长方形是否相交
function flag = find_if_intersect(L1, X1_1, X1_2, L2, X2_1, X2_2, n, m)
    k1 = (X1_1(2) - X1_2(2)) / (X1_1(1) - X1_2(1)); % 第一个长方形的斜率
    k1_ = -1 / k1; % 垂线的斜率
    k2 = (X2_1(2) - X2_2(2)) / (X2_1(1) - X2_2(1)); % 第二个长方形的斜率
    k2_ = -1 / k2; % 垂线的斜率
    X1_center = (X1_1 + X1_2) / 2; % 第一个长方形的中心点
    X2_center = (X2_1 + X2_2) / 2; % 第二个长方形的中心点
    A = [k1_ -1; k2_ -1];
    P = A \ [k1_ * X1_center(1) - X1_center(2); k2_ * X2_center(1) - X2_center(2)]; % 垂线交点
    vec1 = X1_center - P;
    vec2 = X2_center - P;
    theta1 = angle(vec1(1) + 1i * vec1(2));
    theta2 = angle(vec2(1) + 1i * vec2(2));
    delta_theta = theta1 - theta2;
    d1 = norm(vec1);
    d2 = norm(vec2);
    [X, Y] = meshgrid(linspace(d1 - 30e-2 / 2, d1 + 30e-2 / 2, n), linspace(0 - L1 / 2, 0 + L1 / 2, m)); % 均匀离散点
    T = [cos(delta_theta) -sin(delta_theta); sin(delta_theta) cos(delta_theta)];
    XY_new = T * [X(:) Y(:)]'; % 坐标旋转
    flag = find(abs(XY_new(1, :) - d2) < 30e-2 / 2 & abs(XY_new(2, :) - 0) < L2 / 2); % 判断是否相交
end
