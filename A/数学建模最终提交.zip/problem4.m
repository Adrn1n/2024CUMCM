clc; clear;
close all;
dtimestep = 0.005; %仿真步长设置
theta = linspace(0, 2*pi, 100);  % 圆周角度，从0到2*pi，100个点
cicle_r = 500;                          % 圆的半径
xr = cicle_r * cos(theta);              % X 坐标
yr = cicle_r * sin(theta);              % Y 坐标
% 结果矩阵记录
location_record = zeros(14,5);
speed_record = zeros(7,5);

circle_set = 6;
set_pitch = 170;    % 螺距，单位cm
r0 = circle_set * set_pitch;  % 初始半径，单位cm
theta = linspace(0,-circle_set * 2 * pi,  1000);  % 角度，从0到16圈，共1000个点
k = set_pitch / (2 * pi);  % 每弧度的半径增量
% 极坐标方程
r_sym = - k * theta;
% 板凳中心划过的曲线
x_sym = -r_sym .* cos(theta);
y_sym = r_sym .* sin(theta);
cicle_r = r0 + k * theta;
% 板凳中心划过的曲线
cicle_x2 = (cicle_r) .* cos(theta);
cicle_y2 = (cicle_r) .* sin(theta);

r1 = 858/3;  % 第一段圆弧的半径
r2 = 858/6;  % 第二段圆弧的半径，是第一段的一半

% 圆弧旋转角度计算，dy_dx表示y方向与x方向的斜率，jiao是计算得到的旋转角度
dy_dx = 68*2/424/2;  
jiao = atan(dy_dx);  % 得到弧度制的旋转角度，用于后续的角度范围调整

% 定义第一段圆弧的角度范围，linspace生成从-pi+jiao到-2*pi+jiao之间的1000个点的向量
theta_arc1 = linspace(-pi+jiao, -2*pi+jiao, 1000);  
% 根据角度theta_arc1，计算第一段圆弧的局部坐标
arc1_x_local = r1 * cos(theta_arc1) - r2 * cos(jiao);  % x方向坐标，平移至调头区域
arc1_y_local = r1 * sin(theta_arc1) - r2 * sin(jiao);  % y方向坐标，平移至调头区域
% 计算第一段圆弧的半径
r_arc1 = sqrt((arc1_x_local).^2 + (arc1_y_local).^2);

% 定义第二段圆弧的角度范围
theta_arc2 = linspace(-3*pi+jiao, -2*pi+jiao, 500);  
% 计算第二段圆弧的局部坐标，调整位置使其与第一段相切
arc2_x_local = r2 * cos(theta_arc2) + r1 * cos(jiao);  
arc2_y_local = r2 * sin(theta_arc2) + r1 * sin(jiao);
% 计算第二段圆弧的半径
r_arc2 = sqrt((arc2_x_local).^2 + (arc2_y_local).^2);

% 将两段圆弧的坐标拼接在一起
x_sing = [arc1_x_local, arc2_x_local];  % 合并x方向坐标
y_sing = [arc1_y_local, arc2_y_local];  % 合并y方向坐标

% 定义龙头和龙身之间的长度
L1 = 341-55;  % 龙头与第一个龙身成员之间的长度
L = 220-55;   % 各个龙身成员之间的长度

% 初始化速度信息
v0 = 100;  % 初始速度，单位为cm/s（2m/s），限制在不超过2m/s
w0 = v0 / r0;  % 初始角速度

N = 224;  % 总成员数，第223个成员为龙尾前，224为龙尾后

% 初始化每个成员的位置信息（x, y, 和各自走过的距离S）
x_location = r0 * ones(1, N);  % x方向初始位置，全部初始化为圆弧半径r0
y_location = zeros(1, N);      % y方向初始位置，全部为0


% 初始化板凳间的夹角alpha，线速度v_L，木板速度v_M，角速度w
alpha = 2 * asin(0.5 * L / r0) * ones(1, N);  % 每个成员之间的夹角，使用sin函数计算
speed_S = zeros(1, N);  % 初始化线速度
speed_M = zeros(1, N);  % 初始化木板速度
w = zeros(1, N);    % 初始化角速度

% 初始化成员的位置极坐标信息（角度theta和半径rho）
theta0 = 0;  % 初始角度为0
thetaN = -circle_set * 2 * pi;  % 结束时的角度，表示完成多圈旋转
theta = theta0 * ones(1, N);  % 每个成员的角度信息，初始化为theta0
rho = r0 * ones(1, N);  % 每个成员的极坐标半径，初始化为r0

flag = zeros(1, N);  % 用于标识是否到达某个特殊状态的标志变量
flag_turn = zeros(1, N);  % 用于标识是否开始掉头的标志变量
t2 = zeros(1, N);  % 掉头时的时间初始化

%% 迭代过程
iter_j =0;
num = 1; % 进入了多少个板凳
alpha(1) = 2*asin(0.5*L1/r0);
speed_S(1) = v0; % 1m/s
w(1) = speed_S(1)/r0;
% 龙头是否成功抵达边界的标志，到达边界的时间，开始调头的时间
t_arrive = 0; t_turn = 0;
stop=0;

tmin = 58;
tmax = 260; 
dT = 13.48/v0*100;% 用时
for t = 0:dtimestep:tmax
    if (-theta(num)) >= alpha(num)
        num = num +1 ;
        if num > N
            num = N;
        end
    end

    for i = 1:num
        % 位置更新
        if rho(i)>428.8  % 螺线
            flag(i)=0;
            if t2(i)>=dT % 离开圆弧
                theta(i) = theta(i) + w(i)*dtimestep;
                rho(i) = r0 + k * theta(i);
                x_location(i) = -rho(i) * cos(theta(i));
                y_location(i) = -rho(i) * sin(theta(i));
            else    % 进入圆弧前
                theta(i) = theta(i) - w(i)*dtimestep;
                rho(i) = r0 + k * theta(i);
                x_location(i) = rho(i) * cos(theta(i));
                y_location(i) = rho(i) * sin(theta(i));
            end
        else % 进入圆弧1
            t2(i) = t2(i)+dtimestep; 
            if t2(i)>=dT
                t2(i)=dT;
                rho(i)=428.9;
            end
            x_location(i)=x_sing( round(t2(i)/dT*1500));
            y_location(i)=y_sing( round(t2(i)/dT*1500));
        end
        % 速度更新，先更新夹角，再更新速度。木板速度M，线速度L
        if i==1
            alpha(1) = 2*asin(0.5*L1/rho(1));
            speed_S(1) = v0;
            w(1) = speed_S(1)/rho(1);
            speed_M(1) = speed_S(1)*cos(0.5*alpha(1));
        end
        if i >= 2 
            alpha(i) = 2*asin(0.5*L/rho(i));
            speed_S(i) = v0;
            w(i) = speed_S(i)/rho(i);
            speed_M(i) = speed_S(i)*cos(0.5*alpha(i));
        end

        list_position_get=[1,3,5,7,9,11,13;2,4,6,8,10,12,14;1,2,52,102,152,202,224];
        if t>tmin && abs(t-tmin)<1e-1 % -100s
            iter_j = 1;
            for num_j=1:size(list_position_get,2)
                location_record(list_position_get(1,num_j),iter_j) = x_location(list_position_get(3,num_j)); location_record(list_position_get(2,num_j),iter_j) = y_location(list_position_get(3,num_j));
            end

            speed_record(1,iter_j) = speed_M(1); speed_record(2,iter_j) = speed_M(2);
            speed_record(3,iter_j) = speed_M(52); speed_record(4,iter_j) = speed_M(102);
            speed_record(5,iter_j) = speed_M(152); speed_record(6,iter_j) = speed_M(202); speed_record(7,iter_j) = speed_M(224);
        elseif t>tmin && abs(t-tmin-50)<1e-1 % -50s
            iter_j = 2;
            for num_j=1:size(list_position_get,2)
                location_record(list_position_get(1,num_j),iter_j) = x_location(list_position_get(3,num_j)); location_record(list_position_get(2,num_j),iter_j) = y_location(list_position_get(3,num_j));
            end
            speed_record(1,iter_j) = speed_M(1); speed_record(2,iter_j) = speed_M(2);
            speed_record(3,iter_j) = speed_M(52); speed_record(4,iter_j) = speed_M(102);
            speed_record(5,iter_j) = speed_M(152); speed_record(6,iter_j) = speed_M(202); speed_record(7,iter_j) = speed_M(224);
        elseif t>tmin && abs(t-tmin-100)<1e-1 % 0s
            iter_j = 3;
            for num_j=1:size(list_position_get,2)
                location_record(list_position_get(1,num_j),iter_j) = x_location(list_position_get(3,num_j)); location_record(list_position_get(2,num_j),iter_j) = y_location(list_position_get(3,num_j));
            end
            speed_record(1,iter_j) = speed_M(1); speed_record(2,iter_j) = speed_M(2);
            speed_record(3,iter_j) = speed_M(52); speed_record(4,iter_j) = speed_M(102);
            speed_record(5,iter_j) = speed_M(152); speed_record(6,iter_j) = speed_M(202); speed_record(7,iter_j) = speed_M(224);
        elseif t>tmin && abs(t-tmin-150)<1e-1 % 50s
            iter_j = 4;
            for num_j=1:size(list_position_get,2)
                location_record(list_position_get(1,num_j),iter_j) = x_location(list_position_get(3,num_j)); location_record(list_position_get(2,num_j),iter_j) = y_location(list_position_get(3,num_j));
            end
            speed_record(1,iter_j) = speed_M(1); speed_record(2,iter_j) = speed_M(2);
            speed_record(3,iter_j) = speed_M(52); speed_record(4,iter_j) = speed_M(102);
            speed_record(5,iter_j) = speed_M(152); speed_record(6,iter_j) = speed_M(202); speed_record(7,iter_j) = speed_M(224);
        elseif t>tmin && abs(t-tmin-200)<1e-1 % 100s
            iter_j = 5;
            for num_j=1:size(list_position_get,2)
                location_record(list_position_get(1,num_j),iter_j) = x_location(list_position_get(3,num_j)); location_record(list_position_get(2,num_j),iter_j) = y_location(list_position_get(3,num_j));
            end
            speed_record(1,iter_j) = speed_M(1); speed_record(2,iter_j) = speed_M(2);
            speed_record(3,iter_j) = speed_M(52); speed_record(4,iter_j) = speed_M(102);
            speed_record(5,iter_j) = speed_M(152); speed_record(6,iter_j) = speed_M(202); speed_record(7,iter_j) = speed_M(224);
        end
        if stop
            break;
        end
    end % i 循环
    if stop
        break;
    end
end
save_6_locate = round(location_record/100, 6); % result4 文件
save_6_speed = round(speed_record/100, 6); % result4 文件
max_speed = max(save_6_speed(:)); % 展平成向量，查看最大值
disp(max_speed); % 显示最大速度


%%
% 绘制包含龙头和龙身运动轨迹的曲线图

figure(1);
% 绘制填充区域（如背景或路径）
fill(xr, yr, 'y', 'FaceAlpha', 0.3); hold on; % 使用透明度让背景更柔和

% 绘制基本路径线
plot(cicle_x2, cicle_y2, 'color', 'g', 'LineWidth', 1.5); hold on;
plot(x_sym, y_sym, 'r', 'LineWidth', 1.5); hold on;

% 绘制调头路径的S形曲线
plot(arc1_x_local, arc1_y_local, 'color', '#92A8D1', 'LineWidth', 8); hold on; % 使用柔和的蓝灰色
plot(arc2_x_local, arc2_y_local, 'color', '#FF6347', 'LineWidth', 8); % 使用醒目的橙红色

% 绘制运动轨迹
plot(x_location(2:N), y_location(2:N), '-bo', 'LineWidth', 1.5, 'MarkerFaceColor', 'b'); hold on; % 蓝色带圆圈的轨迹
plot(x_location(1:2), y_location(1:2), '-', 'color', 'k', 'LineWidth', 5); % 起始部分加粗的黑线

% 设置坐标轴等比例显示
axis equal;

% 标题设置，动态显示节数和时间
disp(sprintf('结果曲线 1节龙头+%d节龙身运动轨迹（在第%.1f秒结果）', num-1, t), 'FontWeight', 'bold', 'FontSize', 14);

% 设置坐标轴标签
xlabel('X 方向 (cm)', 'FontWeight', 'bold', 'FontSize', 12);
ylabel('Y 方向 (cm)', 'FontWeight', 'bold', 'FontSize', 12);

% 启用网格线，增加对比度
grid on;

% 设置图窗大小和位置
set(gcf, 'Position', [400, 50, 900, 700]);

% 设置坐标轴字体大小
set(gca, 'FontSize', 12);

% 添加图例，便于区分不同轨迹
legend({'背景区域', '基本路径', '对称路径', 'S形调头路径1', 'S形调头路径2', '运动轨迹'}, 'Location', 'BestOutside');

% 调整图形外观
set(gca, 'Box', 'on', 'LineWidth', 1.2); % 使坐标框线更明显


