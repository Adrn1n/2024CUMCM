clc; close all;
warning off;

% 参数定义
luoju = 55e-2; % 螺距
k = luoju / (2 * pi); % 螺线方程的系数 r = k * theta
L1 = 341e-2; 
D1 = L1 - 27.5e-2 * 2; % 龙头把手两个孔之间的距离
L2 = 220e-2;
D2 = L2 - 27.5e-2 * 2; % 其他凳子把手两个孔之间的距离

% 绘制部分螺线
theta = 16 * 2 * pi : -0.01 : 0 * pi; % 定义角度范围
r = k * theta; % 计算半径
x = r .* cos(theta); % 计算 X 坐标
y = r .* sin(theta); % 计算 Y 坐标
figure(1)
set(gcf, 'Position', [200 200 600 600]); % 设置图形窗口大小
plot(x, y, '--') % 绘制螺线
axis equal
grid on
xlabel('x')
ylabel('y')
hold on

% 计算龙头第一个把手的位置演化
mydtheta = @(t, theta) -1 ./ (k * sqrt(1 + theta.^2)); % 定义微分方程
theta0 = 2 * pi * 16; % 初始角度
dt = 1; % 时间步长
tspan = 0:dt:300; % 时间范围
[tt, theta] = ode45(mydtheta, tspan, theta0); % 使用龙格库塔法求解微分方程
X1 = k * theta .* cos(theta); % 计算第一个把手的 X 坐标
Y1 = k * theta .* sin(theta); % 计算第一个把手的 Y 坐标

% 动态绘制龙头第一个把手的轨迹
for i = 1:1:length(theta)
    title({['总时间t=',num2str(tt(i)),'s'], '头部第一个把手中心的轨迹'})
    plot(X1(i), Y1(i), 'r.', 'MarkerSize', 10)
    drawnow
end

hwait = waitbar(0, '计算开始...');

% 计算每个时间点下的孔的位置
N = 223; % 龙头+龙身+龙尾总的孔数
X = zeros(N+1, length(X1)); 
Y = zeros(N+1, length(X1)); 
Theta = zeros(N+1, length(X1)); % 记录每个孔在各个时刻的角度
X(1,:) = X1; % 头部第一个把手的位置
Y(1,:) = Y1;
Theta(1,:) = theta; % 第一个把手的角度

% 循环计算各个孔的位置
for j = 1:length(tt)
    for i = 2:N+1
        % 判断第一个凳子与其他凳子，孔之间的距离不同
        d = D1 * (i <= 2) + D2 * (i > 2);
        thetaij = solve_theta(luoju, X(i-1, j), Y(i-1, j), Theta(i-1, j), d); % 子函数求解下一个孔的角度
        Theta(i, j) = thetaij;
        X(i, j) = k * thetaij * cos(thetaij); % 计算每个孔的 X 坐标
        Y(i, j) = k * thetaij * sin(thetaij); % 计算每个孔的 Y 坐标
        waitbar(((j-1)*N+i)/(length(tt)*N), hwait, '已经完成...');
    end
end

close(hwait);

% 计算每个孔的速度
v = zeros(N+1, length(tt));
v(1, :) = 1; % 第一个孔的速度初始化为1

for j = 2:length(tt)
    for i = 2:N+1
        % 计算各个孔的速度
        tan_phi_i = (sin(Theta(i, j)) + Theta(i, j) * cos(Theta(i, j))) / (cos(Theta(i, j)) - Theta(i, j) * sin(Theta(i, j)));
        tan_phi_i1 = (sin(Theta(i-1, j)) + Theta(i-1, j) * cos(Theta(i-1, j))) / (cos(Theta(i-1, j)) - Theta(i-1, j) * sin(Theta(i-1, j)));
        tan_phi_ij = (Theta(i, j) * sin(Theta(i, j)) - Theta(i-1, j) * sin(Theta(i-1, j))) / (Theta(i, j) * cos(Theta(i, j)) - Theta(i-1, j) * cos(Theta(i-1, j)));
        
        % 更新速度
        v(i, j) = v(i-1, j) * (cos(atan(tan_phi_i1) - atan(tan_phi_ij))) / (cos(atan(tan_phi_ij) - atan(tan_phi_i)));
    end
end

% 确保速度为正
v = abs(v);  % 确保所有速度值为正

% 将结果写入文件
nn = 1 / dt;
index = 1:nn:length(tt);
Dataxy = zeros(2 * (N+1), length(index));
Dataxy(1:2:end, :) = round(X(:, index), 6);
Dataxy(2:2:end, :) = round(Y(:, index), 6);

filename = 'result1.xlsx';
sheet = 1;
xlRange = 'B2';
xlswrite(filename, Dataxy, sheet, xlRange);

% 将速度数据写入文件
DataV = round(v(:, index), 6);
sheet = 2;
xlRange = 'B2';
xlswrite(filename, DataV, sheet, xlRange);

% 记录特定时间点的数据
nn2 = 60 / dt;
index2 = 1:nn2:length(tt);
index_row = [1, 2:50:224, 224];
Dataxy2 = zeros(2 * length(index_row), length(index2)); % 特定时间点位置数据
Dataxy2(1:2:end, :) = round(X(index_row, index2), 6); % x坐标
Dataxy2(2:2:end, :) = round(Y(index_row, index2), 6); % y坐标
Datav2 = round(v(index_row, index2), 6); % 速度信息

% 子函数: 求解下一个孔的角度
function theta = solve_theta(luoju, x1, y1, theta1, d)
    k = luoju / (2 * pi); % 计算系数 k
    fun = @(theta) (k * theta * cos(theta) - x1)^2 + (k * theta * sin(theta) - y1)^2 - d^2; % 利用两点间距离求解
    q = 0.01; % 初始步长
    options = optimoptions('fsolve', 'Display', 'off'); 
    theta = fsolve(fun, theta1 + q, options); % 基于非线性方程求解
    while theta <= theta1 || abs(k * theta - k * theta1) > luoju / 2
        q = q + 0.1; % 增加步长，继续求解
        theta = fsolve(fun, theta + q, options); % 确保求解的角度满足要求
    end
end
